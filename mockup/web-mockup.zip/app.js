/**
 * UI Mockup & Interactive Prototype Logic
 * Antigravity Web Application
 */

// Global State
let currentViewMode = 'grid'; // 'grid' | 'flow'
let currentStep = 1; // 1: Login, 2: SingUp, 3: Address

// Sample Data for Demo
const demoData = {
  login: {
    email: 'user.demo@example.com',
    password: 'Password123!'
  },
  signup: {
    name: 'สมชาย ใจดี',
    email: 'somchai.jaidee@gmail.com',
    password: 'SecretPassword999!',
    confirmPassword: 'SecretPassword999!'
  },
  address: {
    idCard: '1-1020-03456-78-9',
    houseNo: '128/45',
    villageNo: '3',
    province: 'กรุงเทพมหานคร',
    district: 'ปทุมวัน',
    subdistrict: 'ลุมพินี',
    alley: 'ซอยร่วมฤดี',
    road: 'เพลินจิต',
    postalCode: '10330',
    phoneNumber: '089-123-4567'
  }
};

document.addEventListener('DOMContentLoaded', () => {
  setupInputMasks();
  updateViewDisplay();
});

/**
 * Switch between Grid Mode (all 3 screens side-by-side) and Flow Mode (single interactive device)
 */
function switchView(mode) {
  currentViewMode = mode;
  const wrapper = document.getElementById('screens-wrapper');
  const stepper = document.getElementById('flow-stepper');
  const btnGrid = document.getElementById('btn-view-grid');
  const btnFlow = document.getElementById('btn-view-flow');

  if (mode === 'grid') {
    wrapper.classList.remove('flow-mode');
    wrapper.classList.add('grid-mode');
    stepper.style.display = 'none';
    btnGrid.classList.add('active');
    btnFlow.classList.remove('active');
    
    // Remove active-step constraint to show all
    document.querySelectorAll('.device-card').forEach(card => {
      card.classList.remove('active-step');
    });
    showToast('สลับเป็นโหมด: ดู 3 หน้าพร้อมกัน (Overview)');
  } else {
    wrapper.classList.remove('grid-mode');
    wrapper.classList.add('flow-mode');
    stepper.style.display = 'flex';
    btnFlow.classList.add('active');
    btnGrid.classList.remove('active');
    
    goToStep(currentStep);
    showToast('สลับเป็นโหมด: ทดลองใช้งานจริง (Interactive Flow)');
  }
}

/**
 * Navigate to a specific step in Flow Mode (or scroll to it in Grid Mode)
 */
function goToStep(stepNumber) {
  currentStep = stepNumber;

  if (currentViewMode === 'flow') {
    // Hide all, show target step
    document.querySelectorAll('.device-card').forEach(card => {
      card.classList.remove('active-step');
    });
    const targetCard = document.getElementById(`screen-${stepNumber}`);
    if (targetCard) {
      targetCard.classList.add('active-step');
    }

    // Update stepper UI
    for (let i = 1; i <= 3; i++) {
      const stepNav = document.getElementById(`step-nav-${i}`);
      const line = document.getElementById(`line-${i}`);
      if (stepNav) {
        if (i === stepNumber) {
          stepNav.classList.add('active');
        } else if (i < stepNumber) {
          stepNav.classList.add('active');
        } else {
          stepNav.classList.remove('active');
        }
      }
      if (line) {
        if (i < stepNumber) {
          line.classList.add('active');
        } else {
          line.classList.remove('active');
        }
      }
    }
  } else {
    // In grid mode, smoothly scroll target card into view if needed
    const targetCard = document.getElementById(`screen-${stepNumber}`);
    if (targetCard) {
      targetCard.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      targetCard.style.outline = '2px solid #6ce5b9';
      setTimeout(() => {
        targetCard.style.outline = 'none';
      }, 1200);
    }
  }
}

function updateViewDisplay() {
  if (currentViewMode === 'flow') {
    goToStep(currentStep);
  }
}

/**
 * Password Visibility Toggle
 */
function togglePasswordVisibility(inputId, btnElement) {
  const input = document.getElementById(inputId);
  if (!input) return;

  const eyeOpen = btnElement.querySelector('.eye-open');
  const eyeClosed = btnElement.querySelector('.eye-closed');

  if (input.type === 'password') {
    input.type = 'text';
    eyeOpen.style.display = 'none';
    eyeClosed.style.display = 'block';
  } else {
    input.type = 'password';
    eyeOpen.style.display = 'block';
    eyeClosed.style.display = 'none';
  }
}

/**
 * Handle Login Form Submit
 */
function handleLoginSubmit(event) {
  event.preventDefault();
  const email = document.getElementById('login-email').value;
  showToast(`เข้าสู่ระบบสำเร็จด้วย: ${email}`);

  // In flow mode, prompt to next or fill address
  if (currentViewMode === 'flow') {
    setTimeout(() => {
      goToStep(3); // Go to address step
    }, 600);
  }
}

/**
 * Handle SignUp Form Submit
 */
function handleSignupSubmit(event) {
  event.preventDefault();
  const name = document.getElementById('signup-name').value;
  const password = document.getElementById('signup-password').value;
  const confirmPassword = document.getElementById('signup-confirm-password').value;

  if (password !== confirmPassword) {
    showToast('⚠️ รหัสผ่านและการยืนยัน Password ไม่ตรงกัน!');
    const confirmInput = document.getElementById('signup-confirm-password');
    confirmInput.focus();
    confirmInput.style.borderColor = '#ef4444';
    setTimeout(() => {
      confirmInput.style.borderColor = '';
    }, 2000);
    return;
  }

  showToast(`ลงทะเบียนสำเร็จ ยินดีต้อนรับคุณ ${name}!`);

  // Move directly to Step 3 (กรอกที่อยู่) as natural registration progression
  setTimeout(() => {
    goToStep(3);
  }, 600);
}

/**
 * Handle Address Form Submit
 */
function handleAddressSubmit(event) {
  event.preventDefault();

  const idCard = document.getElementById('id-card').value;
  const houseNo = document.getElementById('house-no').value;
  const villageNo = document.getElementById('village-no').value;
  const province = document.getElementById('province').value;
  const district = document.getElementById('district').value;
  const subdistrict = document.getElementById('subdistrict').value;
  const alley = document.getElementById('alley').value;
  const road = document.getElementById('road').value;
  const postalCode = document.getElementById('postal-code').value;
  const phone = document.getElementById('phone-number').value;

  // Build summary rows
  const summaryBox = document.getElementById('summary-data');
  summaryBox.innerHTML = `
    <div class="summary-row"><span class="summary-label">เลขบัตรประชาชน:</span><span class="summary-val">${idCard || '-'}</span></div>
    <div class="summary-row"><span class="summary-label">ที่อยู่:</span><span class="summary-val">${houseNo} ${villageNo ? 'ม.' + villageNo : ''} ${alley ? 'ซ.' + alley : ''} ${road ? 'ถ.' + road : ''}</span></div>
    <div class="summary-row"><span class="summary-label">ตำบล/แขวง:</span><span class="summary-val">${subdistrict || '-'}</span></div>
    <div class="summary-row"><span class="summary-label">อำเภอ/เขต:</span><span class="summary-val">${district || '-'}</span></div>
    <div class="summary-row"><span class="summary-label">จังหวัด:</span><span class="summary-val">${province || '-'}</span></div>
    <div class="summary-row"><span class="summary-label">รหัสไปรษณีย์:</span><span class="summary-val">${postalCode || '-'}</span></div>
    <div class="summary-row"><span class="summary-label">เบอร์โทรศัพท์:</span><span class="summary-val">${phone || '-'}</span></div>
  `;

  const modal = document.getElementById('success-modal');
  modal.style.display = 'flex';
}

/**
 * Close Modal
 */
function closeModal() {
  document.getElementById('success-modal').style.display = 'none';
}

function closeModalAndReset() {
  closeModal();
  document.getElementById('form-login').reset();
  document.getElementById('form-signup').reset();
  document.getElementById('form-address').reset();
  goToStep(1);
  showToast('รีเซ็ตข้อมูลเรียบร้อยแล้ว');
}

/**
 * Social Auth Mock Interactions
 */
function handleSocialAuth(provider) {
  showToast(`กำลังเชื่อมต่อเข้าสู่ระบบผ่าน ${provider}...`);
}

/**
 * Autofill Demo Data Feature
 */
function fillDemoData() {
  // Login Screen
  document.getElementById('login-email').value = demoData.login.email;
  document.getElementById('login-password').value = demoData.login.password;

  // SingUp Screen
  document.getElementById('signup-name').value = demoData.signup.name;
  document.getElementById('signup-email').value = demoData.signup.email;
  document.getElementById('signup-password').value = demoData.signup.password;

  // Address Screen
  document.getElementById('id-card').value = demoData.address.idCard;
  document.getElementById('house-no').value = demoData.address.houseNo;
  document.getElementById('village-no').value = demoData.address.villageNo;
  document.getElementById('province').value = demoData.address.province;
  document.getElementById('district').value = demoData.address.district;
  document.getElementById('subdistrict').value = demoData.address.subdistrict;
  document.getElementById('alley').value = demoData.address.alley;
  document.getElementById('road').value = demoData.address.road;
  document.getElementById('postal-code').value = demoData.address.postalCode;
  document.getElementById('phone-number').value = demoData.address.phoneNumber;

  showToast('✨ กรอกข้อมูลตัวอย่างลงในทุกฟอร์มเรียบร้อยแล้ว!');
}

/**
 * Format input fields as user types (Thai ID card & Phone Number)
 */
function setupInputMasks() {
  const idCardInput = document.getElementById('id-card');
  const phoneInput = document.getElementById('phone-number');

  if (idCardInput) {
    idCardInput.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length > 13) value = value.slice(0, 13);

      // Format as x-xxxx-xxxxx-xx-x
      let formatted = '';
      if (value.length > 0) formatted += value.substring(0, 1);
      if (value.length > 1) formatted += '-' + value.substring(1, 5);
      if (value.length > 5) formatted += '-' + value.substring(5, 10);
      if (value.length > 10) formatted += '-' + value.substring(10, 12);
      if (value.length > 12) formatted += '-' + value.substring(12, 13);

      e.target.value = formatted;
    });
  }

  if (phoneInput) {
    phoneInput.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length > 10) value = value.slice(0, 10);

      // Format as 0xx-xxx-xxxx
      let formatted = '';
      if (value.length > 0) formatted += value.substring(0, 3);
      if (value.length > 3) formatted += '-' + value.substring(3, 6);
      if (value.length > 6) formatted += '-' + value.substring(6, 10);

      e.target.value = formatted;
    });
  }
}

/**
 * Toast Notification Utility
 */
let toastTimeout;
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;

  toast.textContent = message;
  toast.classList.add('show');

  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove('show');
  }, 2800);
}
